var soldier = [
    { "alpha": ["Adams", "Mathew", "James Bond", "Sirius", "Black"] },
    { "bravo": ["Boston", "Johnny Bravo", "Godley", "Stephen", "Jonathan"] },
    { "charlie": ["Chicago", "Constantine", "Edward", "Victor", "Luke"] },
    { "delta": ["Denver", "John Snow", "Iron", "Throne", "McClark"] },
    { "echo": ["Easy", "Tom Cruise", "Tom Holland", "Jackson", "Michael"] },
    { "foxtrot": ["Frank", "Snow White", "Cinderella", "Rapunzel", "Susan"] }
];

var asset = "";
function battalion(a){
    var squad = "";
    squad = asset;

    if(asset = ""){
        return soldier[2];
    }
    else {
        soldier[0][a] = squad;
    }
    
    return soldier;
}

asset = ["Mercury", "Venus", "Earth", "Mars", "Jupiter"];
console.log(battalion("alpha"));

// var assets = "";
// function battalion2(a){
//     var squad = "";
//     squad = soldier;
//     if(assets = ""){
//         return "it aint working";
//     }
//     else {
//         squad[0][a] = assets
//     }
//     return soldier;
// }

// assets = ["jgjgj","jfjfjf","oioti","erhfh","nvbvnf"];
// console.log(battalion2("bravo"));