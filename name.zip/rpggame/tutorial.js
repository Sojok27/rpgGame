// "use strict";
// console.log(2 == "2");
// var people = "";
// var person = "mynameisoperatorsergent";

// people = person[8];
// console.log(people);

// function peace(one, two, three, four){
//     var result = "";
//     result += "The"+" "+one+" "+three+" "+"on the"+" "+two+" "+"chair"+" "+four;
//     return result;
// }
// console.log(peace("mouse", "little", "sat", "quietly"));
// console.log(peace("lion", "large", "jumped", "strongly"));

// var ids = [[2,3,4], [5,6,7], [8,9,0], [1,6,[5,4]]];
// var myid = ids[0];
// console.log(myid);

// var myid = ids[0][1];
// var myids = [ids[0],ids[1]];
// console.log(myid);
// console.log(myids);

// var myid = ids[3][2][0];
// console.log(myid);

// ids.push(7,6,5,7, [8,7,6,5]);
// console.log(ids.length);
// console.log(ids);

// var myidss = ids[4];
// console.log(myidss);

// console.log("it starts from here");
// console.log(ids.length);
// console.log(ids);

// setTimeout(() => {
//     var mid = ids.pop();
//     var top = ids.pop();
//     var bot = ids.pop();
//     console.log(ids.length);
//     console.log(ids);
//     console.log(mid);
//     console.log(top);
//     console.log(bot);
// }, 1000)

// setTimeout(() => {
//     ids.shift();
//     ids.unshift([867], [685], [324]);
//     console.log(ids);
// }, 20000);

$data = [["book", 3], ["shoes", 5], ["pen", 8], ["other stationery", 9]];
console.log($data);
function getData() {
    $book = $data.shift();
    $other_stationery = $data.pop();
    $pen = $data.pop();
    console.log($book);
    console.log($other_stationery);
    console.log($pen, $data);
}
getData();

myData = 30;

function tes1() {
    myDatata = 7;
}
function tes2() {
    var myt = "";
    if (typeof myData != "undefined") {
        myt += "Data: " + myData + " ";
    }
    if (typeof myDatata != "undefined") {
        myt += "NewData: " + myDatata;
    }
    console.log(myt);
}
tes1();
tes2();

var jargon = "bedsheet";
function getJargon() {
    var jargon = "bedspread";
    return jargon;
}
console.log(getJargon());
jargon += getJargon();
console.log(jargon);

function story(book, title, chapter) {
    return "The name of the book is " + book + ", the title is " + title + " " + " and the chapter is " + chapter;
}
console.log(story("harrypotter", "the deathly hollows", "chapter 4"));
console.log(typeof (book));
// $title = "fellowship of the ring";
// $chapter = "chapter 7";
// setTimeout(()=>{
//     if(typeof book == "undefined"){
//         mystic = "New book is: The Lord of the rings";
//         console.log(mystic);
//         console.log(typeof(book));
//         // console.log(story(mystic, $title, $chapter));
//         // return story(mystic, $title, $chapter);
//     }
// }, 1000)
// setTimeout(()=>{
//     console.log(mystic);
//     book = mystic;
//     title = $title;
//     chapter = $chapter;
//     console.log(book);
//     console.log(title);
//     console.log(chapter);
//     console.log(story(book,title,chapter));
//     console.log(typeof(book));
// }, 2000)


list = [3, 4, 5, 6, 7, 8, 9];
// valu = "";
function myList(listing, valu) {
    listing.push(valu);
    valu += listing.shift()
    return valu;
}
// console.log("Before:" + JSON.stringify(list));
// console.log(myList(list,6));
// console.log("Now:" + JSON.stringify(list));
// console.log(valu);


function maths(num, ans) {
    if (ans === "5" || ans == "4") {
        totalSum = num + ans;
        return "the first one is: " + totalSum;
    }
    else if (ans > "4") {
        totalSum = num + ans;
        return "the real first one is: " + totalSum;
    }
    if (ans == "5" && ans == 5) {
        totalSum = num * ans;
        return totalSum;
    }
    else {
        return "ans is not true";
    }
}
console.log(maths(4, 5));
// console.log(maths());

newList = ["real", "unreal", "fake", "reality", "illusion"];
function timetable(tie) {
    var table = "";
    switch (tie) {
        case 1:
        case 6:
            table = newList[0];
            break;
        case 2:
        case 7:
            table = newList[1];
            break;
        case 3:
        case 8:
            table = newList[2];
            break;
        case 4:
        case 9:
            table = newList[3];
            break;
        case 5:
        case 10:
            table = newList[4];
            break;
        default:
            table = "nothing here bro";
    }
    return table;
}
console.log(timetable(1));
console.log(timetable(2));
console.log(timetable(3));
console.log(timetable(4));
console.log(timetable(5));
console.log(timetable(6));
console.log(timetable(7));
console.log(timetable(8));
console.log(timetable(9));
console.log(timetable(10));
console.log(timetable("what"));

function solver(summer, winter, autumn, spring) {
    if (summer < 1) {
        season = summer * winter;
    }
    else if (summer == 1) {
        season = summer * winter + autumn;
    }
    else {
        season = summer * winter + autumn - spring;
    }
    return season < summer;
}
console.log(solver(10, 0, 5, 7));

function math(x, y) {

    if (x < 0 || y < 0) {
        return "value is unknown";
    }

    return Math.round(Math.pow(Math.sqrt(x) + Math.sqrt(y), 3));
}
console.log(math(2, 2));
// a = (Math.sqrt(2) + Math.sqrt(2));
// console.log(a);
// b = a * a;
// console.log(b);

// my bet system
// var trick = 0;

// function blackjack(cards){
//     getCards();
//     cards.forEach(getCards){
//         switch(cards){
//         case 1:
//         case 2:
//         case 3:
//         case 4:
//         case 5:
//         case 6:
//             trick--;
//             break;
//         case 6:
//         case 7:
//         case 8:
//         case 9:
//         case 10:
//         case "J":
//         case "Q":
//         case "K":
//         case "A":
//             trick++;
//             break;
//     }}
//     var dbet = "No bet oh, beta Fold";
//     if(trick > 0){
//         var dbet = "Bet oh, na sure banka,"
//     }
//     return dbet + " why bcos your luck is" + trick;
// }
// blackjack(4),blackjack(6),blackjack(10),blackjack("A"),blackjack("J");
// console.log(blackjack("K"));
// function getCards(){
//     watobet = [1,2,3,4,5,6,7,8,9,10,"J","Q","K","A"];
//     cards = [];
//     cards[0] = watobet[Math.floor(Math.random()*15)];
//     cards[1] = watobet[Math.floor(Math.random()*15)];
//     cards[2] = watobet[Math.floor(Math.random()*15)];
//     cards[3] = watobet[Math.floor(Math.random()*15)];
//     cards[4] = watobet[Math.floor(Math.random()*15)];
//     return cards;
// }

var celebs = {
    13: "Montana",
    14: "Chris Brown",
    "name": "Justin Bieber",
    "my name": "Justin Yieber"
};

var myFav = 14;
var fav = celebs[myFav];
console.log(fav);
console.log(celebs.name);
console.log(celebs["my name"]);

var soldier = {
    "alpha": "Adams",
    "bravo": "Boston",
    "charlie": "Chicago",
    "delta": "Denver",
    "echo": "Easy",
    "foxtrot": "Frank"
};
// console.log(soldier.delta);

// To change all values in soldier object
var newSquad = "";
function fulldetails(war) {
    var squad = "";
    squad = soldier[war];
    if (newSquad == "") {
        return squad;
    }
    else {
        squad = newSquad;
        return squad;
    }
}

// To change only a single value in soldier object
function changeName(team, name) {
    if (team == "") {
        return "not working";
    }
    else {
        soldier[team] = name;
        return soldier;
    }

}
console.log(changeName("alpha", "mathew"));
console.log(changeName("bravo", "Johny Bravo"));

// console.log(typeof (squad));
newSquad = "James Bond";
console.log(fulldetails("alpha"));

function checkSoldier(attendance) {
    if (soldier.hasOwnProperty(attendance)) {
        return soldier[attendance];
    }
    else {
        return "nothing here bro";
    }
}
console.log(checkSoldier("alpha"));

var library = [
    priSch = {
        "mathematics": "General Mathematics",
        "english": "General English",
        "agric": "Introduction to Agricultural Science",
        "intScience": "Elementary Sceince",
        "sos": "Social Studies",
        "civic": "Civil Education",
        "phe": "Introduction to Physical and Health Education"
    },
    secSch = {
        "mathematic": "General Mathematics",
        "englis": "General English",
        "agri": "Introduction to Agricultural Science",
        "intScienc": "Elementary Sceince",
        "ss": "Social Studies",
        "civi": "Civil Education",
        "pe": "Introduction to Physical and Health Education"

    }];

function studies(book) {
    var subject = "";
    subject = library[0][book];
    return subject;
}
console.log(studies("agric"));

function studie(bok) {
    if (secSch.hasOwnProperty(bok)) {
        return secSch[bok];
    }
    else {
        return "nothing dey here";
    }
}
console.log(studie("pe"));

// How to change values in an object and assigned them all to one variable

// var soldier = {
//     "alpha": ["Adams","Mathew","James Bond","Sirius","Black"],
//     "bravo": ["Boston","Johnny Bravo","Godley","Stephen","Jonathan"],
//     "charlie": ["Chicago","Constantine","Edward","Victor","Luke"],
//     "delta": ["Denver","John Snow","Iron","Throne","McClark"],
//     "echo": ["Easy","Tom Cruise","Tom Holland","Jackson","Michael"],
//     "foxtrot": ["Frank","Snow White","Cinderella","Rapunzel","Susan"]
// };

// newSquad = "";
// function battalion(a){
//     var squad = "";
//     squad = soldier[a];
//     if(newSquad == ""){
//         return squad;
//     }
//     else{
//         squad = newSquad;
//     }
//     return squad;
// }
// newSquad = ["Johddndh","uifibv","ijuhfjghi","jvdjvdjej","yrtusiu"];
// console.log(battalion("alpha"));
// console.log(battalion("bravo"));
// console.log(battalion("charlie"));
// console.log(battalion("delta"));
// console.log(battalion("echo"));
// console.log(battalion("foxtrot"));


var storage = {
    "cargo": {
        "perishable": {
            "tomato": 100,
            "egg": 500,
            "orange": 200,
            "pineapple": 150
        },
        "nonPerishable": {
            "peanut": 700,
            "processed cassava": 250,
            "rice": 400,
            "bean": 450
        },
        "stationery": {
            "book": 1000,
            "pen": 2000,
            "pencil": 5000
        }
    },
    "files": "confidential documents"
}
var whatdowehave = storage.cargo.nonPerishable["processed cassava"];
console.log(whatdowehave);



var collection = {
    "2548": {
        "album": "Slippery When Wet",
        "artist": "Bon Jovi",
        "tracks": [
            "Let It Rock",
            "You Give Love a Bad Name"
        ]
    },
    "2468": {
        "album": "When Wet",
        "artist": "Prince",
        "tracks": [
            "Let It Go",
            "Little Red Corvette"
        ]
    },
    "1245": {
        "album": "Fire Away",
        "artist": "Palmer",
        "tracks": []
    },
    "5439": {
        "album": "ABBA Gold"

    }
};
var collectionCopy = JSON.parse(JSON.stringify(collection));
// console.log(collectionCopy);

// This is now a valid way to change any value in the collection object
function updateCollection(id, prop, value) {
    if (value === "") {
        delete collection[id][prop];
    }
    else if (prop === "album") {
        collection[id][prop] = collection[id][prop] || [];
        collection[id][prop].push(value);
    }
    else {
        collection[id][prop] = value;

    }
    return collection;
}
console.log(updateCollection(1245, "tracks", ["wtf", "whatthef"]));

var dArray = [];
var a = 0;
while (a < 4) {
    dArray.push(a);
    a++;
}
console.log(dArray);

for (i = 1; i < 10; i += 2) {
    dArray.push(i);
}
console.log(dArray);

var oArray = [5, 6, 7, 8, 9];
var imi = 0;
for (i = 0; i < oArray.length; i++) {
    imi += oArray[i]
}
console.log(imi);

var query = [];
test = 1;
a = [[1, 2], [3, 4], [5, 6, 7]];
for (t = 0; t < a.length; t++) {
    query.push(a[t]);
}
t = 0;
for (q = 0; q < a[t].length; q++) {
    query.push(a[t][q]);
}
console.log(query);

for (v = 0; v < a.length; v++) {
    for (w = 0; w < a[v].length; w++) {
        test *= a[v][w];
    }
}
console.log(test);

var collections = [
    {
        "album": "Slippery When Wet",
        "artist": "Bon Jovi",
        "tracks": [
            "Let It Rock",
            "You Give Love a Bad Name"
        ]
    },
    {
        "album": "When Wet",
        "artist": "Prince",
        "tracks": [
            "Let It Go",
            "Little Red Corvette"
        ]
    },
    {
        "album": "Fire Away",
        "artist": "Palmer",
        "tracks": []
    },
    {
        "album": "ABBA Gold"

    }
];
function checkCollection(name, prop) {
    for (a = 0; a < collections.length; a++) {
        if (collections[a].album === name) {
            return collections[a][prop] || "artist cant be found";
        }
    }
    return "no album found"
}

console.log(checkCollection("When Wet", "artist"));

function checkNum(num) {
    return num > 0 ? "positive" : num < 0 ? "negative" : "zero";
}
console.log(checkNum(0));

const CHECKER = [2, 4, 5, 6, 7];

function changeChecker(a) {
    "use strict";
    let lists = "";
    for (let b = 0; b < CHECKER.length; b++) {
        CHECKER[b] = a[b];
    }
    lists = CHECKER;
    return lists;
}
console.log(changeChecker([8, 9, 10, 11, 12]));

function changeCheckers() {
    "use strict";
    const MATH_CHECKER = {
        PI: 3.14,
        PO: 2.22
    };
    const MATH_CONSTANT = {
        trt: 9797
    };
    Object.freeze(MATH_CONSTANT);
    try {
        MATH_CHECKER.PI = 76;
        MATH_CHECKER.PO = 66;
        MATH_CONSTANT.trt = 767;
    } catch (ex) {
        console.log(ex)
    }
    return MATH_CHECKER.PI + MATH_CHECKER.PO + MATH_CONSTANT.trt;
}
console.log(changeCheckers());

// anonymous function
const treasure = () => {
    console.log("this is a treasure");
}
var tresure = () => console.log("this is not treasure");
treasure();
tresure();

const realNumberArrat = [4, 5.6, -9.8, 3.14, 42, 6, 8.34, -2]

const squareList = (arr) => {
    const squaredIntegrers = arr.filter(num => Number.isInteger(num) && num > 0).map(x => x * x);
    return squaredIntegrers;
}

const testIntegers = squareList(realNumberArrat);
console.log(testIntegers);

// anonymous function 2
// another way of writing anonymous function
const incre = (function () {
    return function incre(d, e) {
        return d + e;
    };
})();
console.log(incre(5, 4));

a = [5, 6, 7, 8, 9];
a.reduce((prev, curr) => prev + curr, 5);

const right = (function () {
    return function left(x, y, z) {
        const deed = [x, y, z];
        return deed.reduce((prev, curr) => prev + curr, 10)
    }
})();

console.log(right(5, 10, 15));

const up = (function () {
    return function down(...deed) {
        return deed.reduce((prev, curr) => prev + curr, 10);
    };
})();

console.log(up(15, 20, 25, 30, 35));

const fire = ['get','food','for','me'];
let water;
let air;

// anonymous function 3
// also another way of writing anonymous function
(function () {
    water = fire;
    air = [...fire];
    fire[1] = 'water';
})();
console.log(water,air);

const WEATHER  = {
    now : 50,
    tomorrow : 70
};

const tetse = (weather) => {
    const {tomorrow : realweather} = weather;
    return realweather;
};
console.log(tetse(WEATHER));

a = 34;
b = 15;

(() => { 
    [a,b] = [b,a];
    console.log(a,b);
})();

const group = {
    "one" : [1,2,3,4,5,6,7,8,9,0],
    "two" : [1,2,3,4,5,6,7,8,9,0],
    "three" : [1,2,3,4,5,6,7,8,9,0],
    "four" : [1,2,3,4,5,6,7,8,9,0]
}
// console.log(group.one);
const numbe = `The first one is ${group.one},
 the second one is ${group.two}, the thrid one is ${group.three},
 and the last one is ${group.four}.`;

console.log(numbe);

function grupee({two,three,four}){
    const [ , ...twos] = two;
    const [ , , ...threes] = three;
    const [ , , , ...fours] = four;
    // const {two : twos} = grupe;
    group.two = twos;
    group.three = threes;
    group.four = fours;
    return group;
}
console.log(grupee(group));

const number = `The new first one is ${group.one},
 the new second one is ${group.two}, the new thrid one is ${group.three},
 and the new last one is ${group.four}.`;

console.log(number);
// const groupee = () =>{
//     return (function isGroupee({two,three,four}){
//         let twos;
//         let threes;
//         let fours;
//         twos = [ , ...two];
//         threes = [ , ...three];
//         fours = [ , ...four];
//         return twos;
//     })(group);
// }
// console.log(groupee(group));

const reGroup = {
    "one" : ["book","pencil","biro"],
    "two" : ["book","pencil","biro"],
    "three" : ["book","pencil","biro"]
}

const redGroup = (() => {
    return function redeGroup(pass){
    seGroup = [];
    for(i = 0; i < pass.length; i++){
        seGroup.push(`<li class = "text">${pass[i]}</li>`);
    }
    return seGroup;
}
})();

const rGroup = reGroup.two;
console.log(redGroup(rGroup));

function createPerson(name,age,gender){
    return {name, age, gender};
}
const createPersn = (name,age,gender) => ({name,age,gender});

console.log(createPerson("johm",54,"female"));
console.log(createPersn("johm",54,"female"));

const tricycle = {
    wheels : 1,
    hand: function (control){
        this.wheels = control;
    },
    tires(atire){
        this.wheels += atire;
    }
}
tricycle.hand(3);
tricycle.tires(2);
console.log(tricycle.wheels);

// function spaceShip(targetPlanet){
//     this.targetPlanet = targetPlanet;
// }

var spaceShip = function(targetPlanet){
    this.targetPlanet = targetPlanet;
}
var jet = new spaceShip('Mercury');
console.log(jet.targetPlanet);
console.log(jet);

class spaceShp {
    constructor (whatPlanet){
    this.whatPlanet = whatPlanet;
}}
var jets = new spaceShp('Jupiter');
console.log(jets.whatPlanet);   


// this is the way it should be written but for some
// fking reasons they decide with another way

// function makeClass() {
//     class Vegetable {
//         constructor (name){
//             this.name = name;
//         }
//     }
//     var dfruit = new Vegetable('mango');
//     return dfruit.name;
// }
// console.log(makeClass());

// the another freaking way

function makeClass() {
    class Vegetable {
        constructor (name){
            this.name = name;
        }
    }
    return Vegetable;
}
const Vegetable = makeClass();
var dfruit = new Vegetable('mango');
console.log(dfruit.name);

function seeClass(){
    class thermostat{
        constructor(temp){
            this._temp = 5/9 * (temp - 33);
        }
        get temperature(){
            return this._temp;
        }
        set temperature(newTemp){
            this._temp = newTemp;
        }
    }
    return thermostat;
}

const thermostat = seeClass();
const thermo = new thermostat('74');
console.log(thermo._temp);
let realtemperature = thermo.temperature;
console.log(realtemperature);
thermo.temperature = 50;
temps = thermo.temperature;
console.log(temps);

// import and export files but don't know why it aint working
// export const const thermostat = seeClass();
// import { thermostat } from "./tutorial.js";

// I think it's suppose to be like this
// export {thermo};
// export const tempse = 30
// import { thermo } from "./tutorial.js";

// import everything in a file
// import * as temporarySafe from "./tets";

// exporting a single thing from a file as a default
// export default function createPerson(name,age,gender){
//     return {name, age, gender};
// }

// import a default export
// import createPersn from "./tutorial.js";
// console.log(createPerson("johm",54,"female"));
