// let home = 0;
// function bed(num, sick){
//     for( book = 1; book < num; book ++){
//         home += book;
//         sick(book);
//     }
// }
// bed(10, console.log);

// let table = [];
// bed(5, book => {
//     table.push("Unit "+(book+1));
//     // table.push(book+1+"Unit");
// })
// console.log(table);

// function great(n){
//     return m => m > n;
// }
// let greats = great(10);
// console.log(greats(11));

// function noisy(f){
//     return (...args) => {
//         console.log("calling with", args);
//         let result = f(...args);
//         console.log("called with", args, "returned", result);
//         return result;
//     };
// }

// noisy(Math.max)(3,2,1);

// function unless(test, then){
//     if(!test) then();
// }
// repeat(3, n => {
//     unless(n % 2 == 1, () => {
//         console.log(n, "is even");
//     });
// });


// 3 types of for loop

// 1 is forEach loop
// ["A","B"].forEach(l => console.log(l));
// it's the same as the one above
// l = ["A","B"];
// l.forEach(p => {
//   console.log(p);  
// });

// 2 is for/of loop
// function reduce(array,combine,start){
//     let current = start;
//     for (let element of array){
//         current = combine(current, element);
//     }
//     return current;
// }
// console.log(reduce([1,2,3,4], (a,b) => a+b,0));
// console.log([1,2,3,4].reduce((a,b) => a+b,0));

// 3 is for-condition loop
// I wrote this to create a similar to the above
// function reduce(list,combine,start){
//     let current = start;
//     for (let i = 0; i < list.length; i++){
//         current = combine(current, list[i]);
//     }
//     return current;
// }
// console.log(reduce([1,2,3,4], (a,b) => a+b,0))

// this is a true or false comparison "(a) => a > b;"
// only values of same type can be compared else it'll return false on request
// example if an array is compared to an index value it'll always return false
// but if both are either arrays or index or similar values then it'll compare
// and return a true or false statement

// list = [4,5,6,7,8,9];
// lists = [4,5,6,7,8,9, 99];

// the below will return either true or false

// score = (n,m) => n > m;
// console.log(score(lists, list));

function countBy(items, groupName){
    let counts = [];
    for(let item of items){
        let name = groupName(item);
        voice = counts.findIndex(n => n.name == name);
        if(voice == -1){
            counts.push({name, times: 1})
        }
        else {
            counts[voice].times++;
        }
        console.log(counts[0].name);
    }
    return counts;
}
console.log(countBy([1, 2, 3, 4, 5], n => n > 2));

// a = n => n > 2;
// b = [1,2,3,4,5];
// c = [];
// for ( let i = 0; i < b.length; i++){
//     paly = a(b[i]);
//     q = c.findIndex(r => r.p == paly);
//     c.push({paly,q});
// }
// console.log(c);

// function countBy2(items, groupName) {
//     let counts = [];
//     console.log(typeof counts)
//     for (let item of items) {
//         let name = groupName(item);
//         let known = counts.findIndex(c => c.name == name);

//         if (known == -1) {
//             counts.push(
//                 { value: item, 
//                     isFound: known, 
//                     greaterThan2: name,  
//                     times: 1 });
//         } else {
//             counts[known].times++;
//         }
//         console.log(counts)
//     };
//     return counts;
// }
console.log(countBy2([1, 2, 3, 4, 5], n => n > 2));

let arrays = [[1, 2, 3], [4, 5], [6]];
fullArray = [];
// for(let i = 0; i < arrays.length; i++){
//     for(let j = 0; j < arrays[i].length; j++ ){
//         fullArray.push(arrays[i][j]);
//     }}
// console.log(fullArray);
let full = arrays.reduce((prev, curr) => prev.concat(curr));
console.log(full);

// let full = arrays.reduce((prev, curr) => {
//     console.log("Before: ", prev, curr)
//     let latest = prev ? prev.concat(curr) : curr;
//     console.log("After: ", latest)
//     return latest;
// });
// console.log(full);
