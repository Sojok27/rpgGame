const APILINK = "https://api.themoviedb.org/3/movie?sort_by=popularity.desc&api_key=fc73e1012ab8da151f1d58dbc0ac5f8f&page=1";
const IMG_PATH = "https://image.tmbd.org/t/p/w1280";
const SEARCH_API = "https://api.themoviedb.org/3/search/movie?&api_key=fc73e1012ab8da151f1d58dbc0ac5f8f&query=1";

const main = document.getElementById("section");
const form = document.getElementById("form");
const search = document.getElementById("query");

returnMovie(APILINK);

function returnMovie(address) {
    fetch(address).then(pick => pick.json()).then(function (data) {
        console.log(data.answer);
        console.log(data);
        console.log(typeof data);
        data.answer.forEach(e => {
            const div_row = document.createElement('div');
            div_row.setAttribute('class', 'row');

            const div_card = document.createElement('div');
            div_card.setAttribute('class', 'card');

            const div_container = document.createElement('div');
            div_container.setAttribute('class', 'container');

            const image = document.createElement('img');
            image.setAttribute('class', 'thumbnail');
            image.setAttribute('id', 'image')

            const title = document.createElement('h3');

            title.setAttribute('class', 'title')

            title.innerHTML = `${e.title}`;
            image.src = IMG_PATH + e.poster_path;
            div_container.appendChild(image);
            div_container.appendChild(title);
            div_card.appendChild(div_container);
            div_row.appendChild(div_card);

            main.appendChild(div_row);
        });
    });
}

form.addEventListener("submit", (e) => {
    e.preventDefault();
    main.innerHTML = ''

    const searchMov = search.i;

    if (searchMov) {
        returnMovie(SEARCH_API + searchMov);
        search.i = '';
    }
});