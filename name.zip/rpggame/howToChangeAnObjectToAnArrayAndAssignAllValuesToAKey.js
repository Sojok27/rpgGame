// var soldiers = {
//     "alpha": ["Adams","Mathew","James Bond","Sirius","Black"],
//     "bravo": ["Boston","Johnny Bravo","Godley","Stephen","Jonathan"],
//     "charlie": ["Chicago","Constantine","Edward","Victor","Luke"],
//     "delta": ["Denver","John Snow","Iron","Throne","McClark"],
//     "echo": ["Easy","Tom Cruise","Tom Holland","Jackson","Michael"],
//     "foxtrot": ["Frank","Snow White","Cinderella","Rapunzel","Susan"]
// };

// var {"alpha": newSquada, "bravo": newSquadb, "charlie": newSquadc, "delta": newSquadd, "echo": newSquade, "foxtrot": newSquadf} = soldiers;

// // newSquada = ["John","Caezer","Mathew","James","Piscis"];
// console.log(soldiers.alpha);
// console.log(newSquada);


// newSquad = "";
// function battalion(a){
//     var squad = "";
//     squad = soldiers[a];
//     if(newSquad == ""){
//         return squad;
//     }
//     else{
//         squad = newSquad;
//     }
//     return squad;
// }
// newSquad = ["Johddndh","uifibv","ijuhfjghi","jvdjvdjej","yrtusiu"];
// console.log(battalion("alpha"));
// console.log(battalion("bravo"));
// console.log(battalion("charlie"));
// console.log(battalion("delta"));
// console.log(battalion("echo"));
// console.log(battalion("foxtrot"));


var soldier = [
    { "alpha": ["Adams", "Mathew", "James Bond", "Sirius", "Black"] },
    { "bravo": ["Boston", "Johnny Bravo", "Godley", "Stephen", "Jonathan"] },
    { "charlie": ["Chicago", "Constantine", "Edward", "Victor", "Luke"] },
    { "delta": ["Denver", "John Snow", "Iron", "Throne", "McClark"] },
    { "echo": ["Easy", "Tom Cruise", "Tom Holland", "Jackson", "Michael"] },
    { "foxtrot": ["Frank", "Snow White", "Cinderella", "Rapunzel", "Susan"] }
];
// console.log(soldier[1]);

// newSquad = "";
// function battalion(a){
//     var squad = "";
//         squad = soldier;
//     if(newSquad == ""){
//         return soldier;
//     }
//     else{
//         squad[0][a] = newSquad;
//     }
//     return squad;
// }
// newSquad = ["Johddndh","uifibv","ijuhfjghi","jvdjvdjej","yrtusiu"];

// if a parameter is not passed to squad[0] to signify it's values,
// changes will replace both the parameter and it's values but if
// a parameter is passed then changes will be made to only the values.

// if a parameter is not passed to battalion the function will not
// be able to alter the values in alpha-parameter but instead create
// an undefined parameter to assign the values passed.

// if the parameter passed to battalion is the same, the parameter
// in the object squad[0], then changes will be made to the values of
// the parameter, else changes will not be made and an undefined parameter
// will be created for the values passed.

// console.log(battalion());
// console.log(soldier[1]);

newSquad1 = "";
newSquad2 = "";
newSquad3 = "";
newSquad4 = "";
newSquad5 = "";
newSquad6 = "";

function battalion(a, b, c, d, e, f) {
    let squad = "";
    squad = soldier;
    squad[0][a] = newSquad1;
    squad[1][b] = newSquad2;
    squad[2][c] = newSquad3;
    squad[3][d] = newSquad4;
    squad[4][e] = newSquad5;
    squad[5][f] = newSquad6;

    // if(newSquad1 == ""){
    //     return soldier;
    // }
    // else{
    //     squad[0][a] = newSquad1;
    // }
    // if(newSquad2 == ""){
    //     return soldier;
    // }
    // else{
    //     squad[1][b] = newSquad2;
    // }
    // if(newSquad3 == ""){
    //     return soldier;
    // }
    // else{
    //     squad[2][c] = newSquad3;
    // }
    // if(newSquad4 == ""){
    //     return soldier;
    // }
    // else{
    //     squad[3][d] = newSquad4;
    // }
    // if(newSquad5 == ""){
    //     return soldier;
    // }
    // else{
    //     squad[4][e] = newSquad5;
    // }
    // if(newSquad6 == ""){
    //     return soldier;
    // }
    // else{
    //     squad[5][f] = newSquad6;
    // }
    return squad;
}
newSquad1 = ["Johddndh", "uifibv", "ijuhfjghi", "jvdjvdjej", "yrtusiu"];
newSquad2 = ["Johddndh", "uifibv", "ijuhfjghi", "jvdjvdjej", "yrtusiu"];
newSquad3 = ["Johddndh", "uifibv", "ijuhfjghi", "jvdjvdjej", "yrtusiu"];
newSquad4 = ["Johddndh", "uifibv", "ijuhfjghi", "jvdjvdjej", "yrtusiu"];
newSquad5 = ["Johddndh", "uifibv", "ijuhfjghi", "jvdjvdjej", "yrtusiu"];
newSquad6 = ["Johddndh", "uifibv", "ijuhfjghi", "jvdjvdjej", "yrtusiu"];

console.log(battalion("alpha", "bravo", "charlie", "delta", "echo", "foxtrot"));