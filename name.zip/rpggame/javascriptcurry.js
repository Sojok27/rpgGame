var a = 9
function outer(){
    b = 5
    function inner(){
        c = 4
        function call(){
            d = a + b  + c
            console.log(d)
        }
        call()
    }
    inner()
}
outer()

function cury(meal){
    return function(rice){
        return function(beans){
            return function(meat){
                return meal(rice, beans, meat)
            }
        }
    }
}

function food(tea,milk,bread,coffee){
        //    return tea + milk + bread + coffee;
                bread = coffee + milk;
    return function alpha(){
                tea = milk+coffee;
        return function beta(){
                coffee = tea + milk
            return function charlie(){
                return tea + milk + bread + coffee;
                }
            }
    }
 }
console.log(food(5,6,7,8)()()())








































