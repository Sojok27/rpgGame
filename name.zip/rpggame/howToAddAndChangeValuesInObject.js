var collection = {
    "2548": {
        "album": "Slippery When Wet",
        "artist": "Bon Jovi",
        "tracks": [
            "Let It Rock",
            "You Give Love a Bad Name"
        ]
    },
    "2468": {
        "album": "When Wet",
        "artist": "Prince",
        "tracks": [
            "Let It Go",
            "Little Red Corvette"
        ]
    },
    "1245": {
        "album": "Fire Away",
        "artist": "Palmer",
        "tracks": [ ]
    },
    "5439": {
        "album": "ABBA Gold"

    }
};
var collectionCopy = JSON.parse(JSON.stringify(collection));

function updateCollection(id,prop,value){
    var title = id;
    var type = prop;
    var details = value;

    if(value === ""){
        delete collection[id][prop];
    }
    else if(prop === "album"){
        collection[id][prop] = collection[id][prop] || [];
        collection[id][prop].push(value);
    }
    else{
        collection[id][prop] = value;
    }
    return collection;
}

var title = "1999s Hit song";
var type = "Rock Pop";
var details = "Fun Funky Let's go";

console.log(updateCollection(title,type,details));